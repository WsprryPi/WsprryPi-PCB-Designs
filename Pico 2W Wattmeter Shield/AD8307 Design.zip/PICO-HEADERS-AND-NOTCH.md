# Pico female socket BOM and antenna notch

Updated 2026-09-17 with KiCad 10.0.1.

The PCB keeps the combined `Raspberry_Pi_Pico_2W_Header` footprint: two rows of
20 plated holes, 2.54 mm pitch, 17.78 mm row spacing, 1.00 mm drills, and
1.508 × 1.508 mm pads. Its pin numbering, existing pad settings, silkscreen,
courtyards, placement, and routing are unchanged.

## Bill of materials

J2 and J3 are pinless, BOM-only symbols for **female 1×20 socket headers at
2.54 mm pitch**. Their `Exclude from board` attribute prevents duplicate
footprints. They are also excluded from simulation and placement outputs.
Their two physical rows are represented by the existing U3 footprint.

U3 is the shield's electrical interface and is now excluded from the purchasing
BOM and placement outputs. The Pico module itself is therefore not counted as
a part purchased for this shield. Its electrical symbol, connections, and
physical footprint remain present. Enable U3's BOM inclusion separately if an
assembly BOM must also purchase the Pico module.

The saved **Shield purchasing BOM** preset produces:

| References | Quantity | Value |
| --- | --- | --- |
| J2, J3 | 2 | Socket_1x20_P2.54mm |

Exact socket manufacturer, part number, body width, and mating height are not
assigned. Select a specific part with leads compatible with the existing holes
and the intended Pico/header stack. This edit does not claim an arbitrary socket
will mechanically fit. Populate both symbols' Manufacturer and MPN fields with
the same selected part; those fields are included in BOM grouping and export.

Generate the purchasing BOM from the **schematic**, using Tools → Generate BOM
and the preset above. A PCB-only footprint list cannot enumerate these two
schematic-only procurement items.

## Reuse

The project-local design block is
`pico-wattmeter:Pico_2W_Two_Female_Sockets`. It contains the Pico interface symbol
with the combined footprint assignment and both BOM-only socket symbols.
Application-specific wiring and no-connect flags are intentionally omitted.

In the Schematic Editor, open **View → Panels → Design Blocks**, select the
`pico-wattmeter` library, and place `Pico_2W_Two_Female_Sockets`. Wire the Pico
interface as required and use Update PCB from Schematic. The PCB receives one
combined footprint and the BOM receives two socket entries. Placing the bare
Pico symbol or footprint alone does not add the socket procurement symbols.

The block is registered through `${KIPRJMOD}` in `design-block-lib-table`.
To reuse it in another project, make the accompanying symbol, footprint, and
design-block libraries available there under the same `pico-wattmeter` nickname.
There is no machine-specific path in the new registration.

## Antenna opening

The old `Antenna Cutout` was a rule area on `Edge.Cuts`; it did not remove board
material. The header footprint now carries three real `Edge.Cuts` lines defining
a nominal **14 mm-wide × 9 mm-deep open notch**. Its local endpoints are
(-7.89, 26.65) and (6.11, 26.65) mm, with its inner edge at y = 17.65 mm.

On this PCB, the opening occupies x = 164.46–173.46 mm and
y = 82.69–96.69 mm. The former straight right edge was split at those endpoints
and joined to the footprint's notch, forming one closed board perimeter.
The board retains all header holes. The former rule area was moved to F.Cu and
B.Cu and renamed `Pico antenna keepout`; it still forbids tracks, vias, pads,
copper pours, and footprints in that region. Copper was refilled around the
new physical edge.

When this footprint is placed on another board, **join its two notch endpoints
to that board's outer outline**. A footprint cannot automatically trim the
receiving board's edge. Do not leave a straight edge across the notch mouth or
add a fourth closing side at that edge. If the footprint is moved on this board,
update the attached outline segments too. Confirm the fabricator's internal
corner radius when preparing fabrication; physical fit and RF performance are
not validated by these CAD checks.

The geometry follows the antenna clearance area in the
[Pico 2 W datasheet](https://datasheets.raspberrypi.com/picow/pico-2-w-datasheet.pdf).
See also KiCad's
[footprint graphics](https://docs.kicad.org/10.0/en/pcbnew/pcbnew.html#footprint_graphics_and_text),
[BOM documentation](https://docs.kicad.org/10.0/en/eeschema/eeschema.html#generating_a_bill_of_materials),
and [design blocks](https://docs.kicad.org/10.0/en/eeschema/eeschema.html#design_blocks).

## Changed source files

- [Schematic](Pico%202W%20Wattmeter%20Shield.kicad_sch): embedded socket definition,
  J2/J3 procurement symbols and note, U3 BOM/placement attributes.
- [PCB](Pico%202W%20Wattmeter%20Shield.kicad_pcb): U3 notch/keepout and attributes,
  split right edge, regenerated copper fills and teardrops.
- [Project](Pico%202W%20Wattmeter%20Shield.kicad_pro): purchasing BOM preset/settings.
- [Symbol library](pico-wattmeter.kicad_sym): reusable pinless female socket symbol.
- [Header footprint](pico-wattmeter.pretty/Raspberry_Pi_Pico_2W_Header.kicad_mod):
  reusable notch, copper keepout, BOM/placement exclusion attributes.
- [Design-block registration](design-block-lib-table).
- [Design-block schematic](pico-wattmeter.kicad_blocks/Pico_2W_Two_Female_Sockets.kicad_block/Pico_2W_Two_Female_Sockets.kicad_sch).
- [Design-block metadata](pico-wattmeter.kicad_blocks/Pico_2W_Two_Female_Sockets.kicad_block/Pico_2W_Two_Female_Sockets.json).
- This note.

## Validation

- KiCad 10.0.1 ERC: 0 errors and 0 warnings.
- DRC: 0 violations, 0 unconnected items, and 0 schematic parity issues.
- All 89 placed pads, 84 track segments, and 13 vias are unchanged, including
  their UUIDs and teardrop settings. All 40 library pads and existing library
  graphics/field UUIDs were preserved.
- Schematic wires, junctions, labels, and no-connect flags are unchanged.
- Board/DRC settings and ERC configuration are unchanged. ERC retains its four
  pre-existing ignored check categories; no DRC exclusions were added.
- Native BOM export verified J2/J3 quantity 2 and U3 omitted. The reusable block
  also parsed/exported successfully and produced a two-socket BOM.
- Visually inspected the complete notch, both copper sides, and the socket
  entries below the Pico schematic symbol. No physical or RF test was performed.

Regenerable reports, BOMs, source snapshots/differences/hashes, and visual exports
are in `generated/headers-notch-2026-09-17/`. No commit or push was performed.
